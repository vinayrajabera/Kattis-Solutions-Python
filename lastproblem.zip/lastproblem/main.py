def main():
    s= input()

    print(f"Thank you, {s}, and farewell!")

main()